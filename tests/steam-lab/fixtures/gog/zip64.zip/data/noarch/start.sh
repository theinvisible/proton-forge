#!/bin/sh
exec ./game/bin/game "$@"
