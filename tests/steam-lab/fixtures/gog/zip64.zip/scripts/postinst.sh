#!/bin/sh
echo no
